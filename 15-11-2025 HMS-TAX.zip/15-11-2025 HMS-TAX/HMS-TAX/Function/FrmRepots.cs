﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ComponentFactory.Krypton.Toolkit;
using HMS_TAX.UserDefined;
using Excel = Microsoft.Office.Interop.Excel;

namespace HMS_TAX.Function
{
    public partial class FrmRepots : KryptonForm
    {
        public FrmRepots()
        {
            InitializeComponent();
        }

        sqlexcute sql = new sqlexcute();
        public string PStatus = string.Empty;
        public string PCode = string.Empty;

        public string Status
        {
            get { return PStatus; }
            set { PStatus = value; }
        }

        public string Code
        {
            get { return PCode; }
            set { PCode = value; }
        }


        void FormatDataGridview()
        {
            try
            {
                for (int i = 0; i < rtpData.Columns.Count; i++)
                {
                    rtpData.Columns[i].ReadOnly = true;
                    rtpData.Columns[i].Width = 222;
                }

                rtpData.Columns["vrpt_name"].Visible = false;
                rtpData.Columns["vrpt_id"].Width = 30;

                rtpData.AutoResizeColumnHeadersHeight();

                // Resize all the row heights to fit the contents of all non-header cells.
                rtpData.AutoResizeRows(
                    DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders);

                //txtTypeCode
                this.rtpData.ColumnHeadersDefaultCellStyle.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Pixel);
                rtpData.ColumnHeadersDefaultCellStyle.ForeColor = Color.Red;


                this.rtpData.DefaultCellStyle.Font = new Font("Times New Roman", 16F, FontStyle.Italic, GraphicsUnit.Pixel);
                this.rtpData.DefaultCellStyle.ForeColor = Color.Black;
            }
            catch { }
        }

        void rpt_list(string vstatus)
        {
            try
            {
                DataTable dblist = new DataTable();
                string[] p = {
                     vstatus,
                     variables.PBranchCode,
                     ""
                    };
                rtpData.Rows.Clear();
                dblist = sql.proc_getdata("proc_rpt_sql", p);
                if (dblist.Rows.Count > 0)
                {
                    for (int i = 0; i < dblist.Rows.Count; i++)
                    {
                        rtpData.Rows.Add(
                            dblist.Rows[i]["code"].ToString(),
                            (i + 1).ToString(),
                            dblist.Rows[i]["name"].ToString()
                        );
                    }
                }
                else
                {


                }
            }
            catch { }
        }

        bool IsOk()
        {

            return true;
        }

        void rpt_po_summary()
        {
            try
            {
                DataTable dt = new DataTable();
                List<parasql> arr = new List<parasql>();
                arr.Add(new parasql { paraname = "@vBranchCode", sqltype = SqlDbType.NVarChar, values = variables.PBranchCode });
                arr.Add(new parasql { paraname = "@vsup_id", sqltype = SqlDbType.NVarChar, values = cbosupply.SelectedValue.ToString() });
                arr.Add(new parasql { paraname = "@vsto_id", sqltype = SqlDbType.NVarChar, values = cboStock.SelectedValue.ToString() });
                arr.Add(new parasql { paraname = "@vpro_id", sqltype = SqlDbType.NVarChar, values = cboProduct.SelectedValue.ToString() });
                arr.Add(new parasql { paraname = "@vline_id", sqltype = SqlDbType.NVarChar, values = cboLine.SelectedValue.ToString() });
                arr.Add(new parasql { paraname = "@vmol_id", sqltype = SqlDbType.NVarChar, values = cboMolecule.SelectedValue.ToString() });
                arr.Add(new parasql { paraname = "@vpacking_id", sqltype = SqlDbType.NVarChar, values = cboPacking.SelectedValue.ToString() });
                arr.Add(new parasql { paraname = "@vdate_from", sqltype = SqlDbType.NVarChar, values = dtFrom.Value.ToString("yyyy/MM/dd") });
                arr.Add(new parasql { paraname = "@vdate_to", sqltype = SqlDbType.NVarChar, values = dtTo.Value.ToString("yyyy/MM/dd") });

                dt = sql.Data_Execute("rpt_po_summary", arr);

                if (dt.Rows.Count > 0)
                {

                    Excel.Application excelApplication = null;
                    Excel.Workbook workbookTemplate = null;
                    Excel.Workbook workbookReport = null;
                    Microsoft.Office.Interop.Excel.Worksheet ws;
                    try
                    {
                        excelApplication = new Excel.Application();
                        excelApplication.SheetsInNewWorkbook = 1;
                        excelApplication.DisplayAlerts = false;

                        // Open the template
                        workbookTemplate = excelApplication.Workbooks.Open(System.Windows.Forms.Application.StartupPath + @"\Reports\rpt_po_summary.xlsx");

                        // Create working report
                        workbookReport = excelApplication.Workbooks.Add(Type.Missing);
                        workbookTemplate.Sheets[1].Copy(workbookReport.Worksheets[1]);
                        ws = (Microsoft.Office.Interop.Excel.Worksheet)workbookReport.Worksheets[1];

                        int Start = 6;
                        ws.Cells[4, "D"] = DateTime.Today;
                        progressbarsetup.Visible = true;
                        progressbarsetup.Minimum = 0;
                        progressbarsetup.Maximum = dt.Rows.Count + 1;

                        for (int i = 0; i < dt.Rows.Count; i++)
                        {

                            ws.Cells[Start + i, "B"] = (i + 1).ToString();
                            ws.Cells[Start + i, "C"] = dt.Rows[i]["po_id"].ToString();
                            ws.Cells[Start + i, "D"] = dt.Rows[i]["sup_name"].ToString();
                            ws.Cells[Start + i, "E"] = dt.Rows[i]["pro_name"].ToString();
                            ws.Cells[Start + i, "F"] = dt.Rows[i]["cost"].ToString();
                            ws.Cells[Start + i, "G"] = dt.Rows[i]["oth_cost"].ToString();
                            ws.Cells[Start + i, "H"] = dt.Rows[i]["qty"].ToString();
                            ws.Cells[Start + i, "I"] = dt.Rows[i]["amount"].ToString();
                            ws.Cells[Start + i, "J"] = dt.Rows[i]["sto_name"].ToString();

                            progressbarsetup.Value = (i + 1);

                        }

                        progressbarsetup.Value = 0;
                        progressbarsetup.Visible = false;
                        workbookTemplate.Close();
                        // Set the active sheet
                        ((Excel.Worksheet)excelApplication.ActiveWorkbook.Sheets[1]).Select(Type.Missing);
                        // Show the report
                        excelApplication.Visible = true;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.ToString());
                    }
                }
                else
                {
                    MessageBox.Show("No data display .", variables.vTittle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    progressbarsetup.Visible = false;
                }
            }
            catch { }
        }
        void rpt_po_details()
        {
            try
            {
                DataTable dt = new DataTable();
                List<parasql> arr = new List<parasql>();
                arr.Add(new parasql { paraname = "@vBranchCode", sqltype = SqlDbType.NVarChar, values = variables.PBranchCode });
                arr.Add(new parasql { paraname = "@vsup_id", sqltype = SqlDbType.NVarChar, values = cbosupply.SelectedValue.ToString() });
                arr.Add(new parasql { paraname = "@vsto_id", sqltype = SqlDbType.NVarChar, values = cboStock.SelectedValue.ToString() });
                arr.Add(new parasql { paraname = "@vpro_id", sqltype = SqlDbType.NVarChar, values = cboProduct.SelectedValue.ToString() });
                arr.Add(new parasql { paraname = "@vline_id", sqltype = SqlDbType.NVarChar, values = cboLine.SelectedValue.ToString() });
                arr.Add(new parasql { paraname = "@vmol_id", sqltype = SqlDbType.NVarChar, values = cboMolecule.SelectedValue.ToString() });
                arr.Add(new parasql { paraname = "@vpacking_id", sqltype = SqlDbType.NVarChar, values = cboPacking.SelectedValue.ToString() });
                arr.Add(new parasql { paraname = "@vdate_from", sqltype = SqlDbType.NVarChar, values = dtFrom.Value.ToString("yyyy/MM/dd") });
                arr.Add(new parasql { paraname = "@vdate_to", sqltype = SqlDbType.NVarChar, values = dtTo.Value.ToString("yyyy/MM/dd") });

                dt = sql.Data_Execute("rpt_po_details", arr);
                if (dt.Rows.Count > 0)
                {
                    Excel.Application excelApplication = null;
                    Excel.Workbook workbookTemplate = null;
                    Excel.Workbook workbookReport = null;
                    Microsoft.Office.Interop.Excel.Worksheet ws;
                    try
                    {
                        excelApplication = new Excel.Application();
                        excelApplication.SheetsInNewWorkbook = 1;
                        excelApplication.DisplayAlerts = false;

                        // Open the template
                        workbookTemplate = excelApplication.Workbooks.Open(System.Windows.Forms.Application.StartupPath + @"\Reports\rpt_po_details.xlsx");

                        // Create working report
                        workbookReport = excelApplication.Workbooks.Add(Type.Missing);
                        workbookTemplate.Sheets[1].Copy(workbookReport.Worksheets[1]);
                        ws = (Microsoft.Office.Interop.Excel.Worksheet)workbookReport.Worksheets[1];

                        int Start = 6;
                        ws.Cells[4, "D"] = DateTime.Today;
                        progressbarsetup.Visible = true;
                        progressbarsetup.Minimum = 0;
                        progressbarsetup.Maximum = dt.Rows.Count + 1;

                        for (int i = 0; i < dt.Rows.Count; i++)
                        {

                            ws.Cells[Start + i, "B"] = (i + 1).ToString();
                            ws.Cells[Start + i, "C"] = dt.Rows[i]["po_id"].ToString();
                            ws.Cells[Start + i, "D"] = dt.Rows[i]["sup_name"].ToString();
                            ws.Cells[Start + i, "E"] = dt.Rows[i]["po_date"].ToString();
                            ws.Cells[Start + i, "F"] = dt.Rows[i]["pro_name"].ToString();
                            ws.Cells[Start + i, "G"] = dt.Rows[i]["cost"].ToString();
                            ws.Cells[Start + i, "H"] = dt.Rows[i]["oth_cost"].ToString();
                            ws.Cells[Start + i, "I"] = dt.Rows[i]["qty"].ToString();
                            ws.Cells[Start + i, "J"] = dt.Rows[i]["discount"].ToString();
                            ws.Cells[Start + i, "K"] = dt.Rows[i]["amount"].ToString();
                            ws.Cells[Start + i, "L"] = dt.Rows[i]["sto_name"].ToString();
                            ws.Cells[Start + i, "M"] = dt.Rows[i]["exp_date"].ToString();
                            ws.Cells[Start + i, "N"] = dt.Rows[i]["inputter"].ToString();
                            ws.Cells[Start + i, "O"] = dt.Rows[i]["batch_id"].ToString();

                            progressbarsetup.Value = (i + 1);

                        }

                        progressbarsetup.Value = 0;
                        progressbarsetup.Visible = false;
                        workbookTemplate.Close();
                        // Set the active sheet
                        ((Excel.Worksheet)excelApplication.ActiveWorkbook.Sheets[1]).Select(Type.Missing);
                        // Show the report
                        excelApplication.Visible = true;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.ToString());
                    }
                }
                else
                {
                    MessageBox.Show("No data display .", variables.vTittle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    progressbarsetup.Visible = false;
                }

            }
            catch { }
        }


        private void FrmRepots_Load(object sender, EventArgs e)
        {
            try
            {
                FormatDataGridview();
                rpt_list("rpt_name");

                sql.Filter_ComboBox(cboStock, "exec proc_rpt_sql  'rpt_cbo_stock','" + variables.PBranchCode + "','%'", "name", "code");
                sql.Filter_ComboBox(cboProduct, "exec proc_rpt_sql  'rpt_product','" + variables.PBranchCode + "','%'", "name", "code");
                sql.Filter_ComboBox(cboCustomer, "exec proc_rpt_sql  'rpt_customer','" + variables.PBranchCode + "','%'", "name", "code");
                sql.Filter_ComboBox(cbosupply, "exec proc_rpt_sql  'rpt_supply','" + variables.PBranchCode + "','%'", "name", "code");

                sql.Filter_ComboBox(cboLine, "exec proc_rpt_sql  'rpt_line','" + variables.PBranchCode + "','%'", "name", "code");
                sql.Filter_ComboBox(cboMolecule, "exec proc_rpt_sql  'rpt_Mol','" + variables.PBranchCode + "','%'", "name", "code");
                sql.Filter_ComboBox(cboPacking, "exec proc_rpt_sql  'rpt_packing','" + variables.PBranchCode + "','%'", "name", "code");

            }
            catch { }
        }

        private void rtpData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                lblShow.Text ="Getting : "+rtpData[2, e.RowIndex].Value.ToString();
                PCode = rtpData[0, e.RowIndex].Value.ToString();
            }
            catch { }
        }
       

        private void btnOk_Click(object sender, EventArgs e)
        {
            try
            {
                if (IsOk() == true)
                {
                    if (Code == "rpt_po_details")
                    {
                        rpt_po_details();
                    }
                    else if (Code == "rpt_po_summary")
                    {
                        rpt_po_summary();
                    }
                }
            }
            catch { }
        }
    }
}
